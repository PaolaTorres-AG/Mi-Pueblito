
<?php $__env->startSection('title', 'Mi Pueblito'); ?>
<?php $__env->startSection('content_header'); ?>
<style>
  #mydatatable tfoot {
          display: table-header-group !important;
      }
      #mydatatable tfoot {
          display: table-header-group !important;
      }
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap');
* {
padding: 0;
margin: 0;
font-family: 'Poppins', sans-serif;
}
      </style>
      <p style="font-weight: bold;color:#f2ca28; text-align: right;">¡BIENVENIDO <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?> !</p>
      <div class="flash-message">
        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Session::has('alert-' . $msg)): ?>  
          <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div> <!-- end .flash-message -->
 <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
 <div class=" m-0 p-0 card bg-gradient-to-tr  from-gray-500 to-gray-900  rounded-lg  text-white font-bold text-md">
    <div class="card-body m-2 p-0">
        <h5 class="text-center">Consultar activos asignados a: <?php echo e($users->name); ?> <?php echo e($users->lastname); ?> 
          <a href="<?php echo e(URL::route('PaseSalida',$users->id)); ?>" class="btn btn-secondary btn-sm" tabindex="-1" role="button"><i class="fa-regular fa-file-pdf fa-sm"></i></a> 
         
        </h5> 
    </div>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 





<div class="m-4">
    <div class="card text-center">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs" id="myTab">
                <li class="nav-item">
                    <a href="#home" class="nav-link active" data-bs-toggle="tab">EQUIPOS</a>
                </li>
                <li class="nav-item">
                    <a href="#profile" class="nav-link" data-bs-toggle="tab">DISPOSITIVOS</a>
                </li>
                <li class="nav-item">
                    <a href="#messages" class="nav-link" data-bs-toggle="tab">CONTRASEÑAS</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div class="tab-pane fade show active" id="home">
                  <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  
                    <div class="card">
                      <form id="form<?php echo e($equipo->id); ?>" name="form<?php echo e($equipo->id); ?>" class="rounded" method="POST"  action="<?php echo e(route('VerAsignacionpost',$equipo->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-header">
                         Equipos Asignados <button type="button" class="btn btn-secondary" value="<?php echo e($equipo->id); ?>" name="btn1<?php echo e($equipo->id); ?>" id="btn1<?php echo e($equipo->id); ?>" onclick="disable(this.value)"><i class="fa-solid fa-unlock"></i> </button> <button type="button" class="btn btn-secondary" name="btn2<?php echo e($equipo->id); ?>" id="btn2<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->id); ?>" onclick="enable(this.value)" style="display: none"><i class="fa-solid fa-lock"></i></button> <button type="submit" id="save<?php echo e($equipo->id); ?>" nameid="save<?php echo e($equipo->id); ?>" class="btn btn-dark" disabled><i class="fa-solid fa-pen-to-square"></i></button>
                        </div>
                        <div class="card-body">
                       
                       
                            <div class="container text-center">
                                <div class="row">
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Estado del equipo</label>
                                    <select class="form-select"id="estado<?php echo e($equipo->id); ?>" name="estado<?php echo e($equipo->id); ?>" disabled>
                                      <option selected value="<?php echo e($equipo->estado_disp); ?>"><?php echo e($equipo->estado_disp); ?></option>
                                      <option  value="REASIGNADO">REASIGNADO</option>
                                      <option  value="NUEVO">NUEVO</option>
                                    </select>
                                    
                                    <input type="hidden" class="form-control text-xs" id="id<?php echo e($equipo->id); ?>" name="id<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->id); ?>" >
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Tipo de dispositivo</label>
                                    <select class="form-select" id="tipodisp<?php echo e($equipo->id); ?>" name="tipodisp<?php echo e($equipo->id); ?>" disabled>
                                      <option selected value="<?php echo e($equipo->tipo_disp); ?>" selected><?php echo e($equipo->tipo_disp); ?></option>
                                      <option  value="LAPTOP">LAPTOP</option>
                                      <option  value="PC">PC</option>
                                    </select>
                                    
                                  </div>
                                  
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Nombre del equipo</label>
                                    <input type="text" class="form-control text-xs" id="nombredisp<?php echo e($equipo->id); ?>" name="nombredisp<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->nombre_disp); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Marca</label>
                                    <input type="text" class="form-control text-xs" id="marca<?php echo e($equipo->id); ?>" name="marca<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->marca); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Modelo</label>
                                    <input type="text" class="form-control text-xs" id="modelo<?php echo e($equipo->id); ?>" name="modelo<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->modelo); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Numero de serie</label>
                                    <input type="text" class="form-control text-xs" id="nserie<?php echo e($equipo->id); ?>" name="nserie<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->num_serie); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Procesador y velocidad</label>
                                    <input type="text" class="form-control text-xs" id="pv<?php echo e($equipo->id); ?>" name="pv<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->proc_velocidad); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Memoria</label>
                                    <input type="text" class="form-control text-xs" id="memoria<?php echo e($equipo->id); ?>" name="memoria<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->memoria); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Almacenamiento</label>
                                    <input type="text" class="form-control text-xs" id="alm<?php echo e($equipo->id); ?>" name="alm<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->disco); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Fecha de compra</label>
                                    <input type="date" class="form-control text-xs" id="fcompra<?php echo e($equipo->id); ?>" name="fcompra<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->fecha_compra); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Fecha de asignación</label>
                                    <input type="date" class="form-control text-xs" id="fasig<?php echo e($equipo->id); ?>" name="fasig<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->fecha_entrega); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Proveedor</label>
                                    <input type="text" class="form-control text-xs" id="prov<?php echo e($equipo->id); ?>" name="prov<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->proveedor); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Sistema operativo</label>
                                    <input type="text" class="form-control text-xs" id="so<?php echo e($equipo->id); ?>" name="so<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->so); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Ip del dispositivo</label>
                                    <input type="text" class="form-control text-xs" id="ipd<?php echo e($equipo->id); ?>" name="ipd<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->ip); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Correo del dispositivo</label>
                                    <input type="text" class="form-control text-xs" id="correo<?php echo e($equipo->id); ?>" name="correo<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->correo_disp); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">MAC</label>
                                    <input type="text" class="form-control text-xs" id="mac<?php echo e($equipo->id); ?>" name="mac<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->mac); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Wifi/Ethernet</label>
                                    <select class="form-select" id="wifieth<?php echo e($equipo->id); ?>" name="wifieth<?php echo e($equipo->id); ?>" required disabled>
                                      <option selected value="<?php echo e($equipo->wifi_ethernet); ?>" selected><?php echo e($equipo->wifi_ethernet); ?></option>
                                      <option  value="WIFI" >WIFI</option>
                                      <option  value="ETHERNET" >ETHERNET</option>
                                    </select>
                                    
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">IP/DHCP</label>
                                    <select class="form-select" id="ipdhcp<?php echo e($equipo->id); ?>" name="ipdhcp<?php echo e($equipo->id); ?>" disabled required>
                                      <option selected value="<?php echo e($equipo->ip_dhcp); ?>" selected><?php echo e($equipo->ip_dhcp); ?></option>
                                      <option  value="IP" >IP</option>
                                      <option  value="DHCP" >DHCP</option>
                                    </select>
                                    
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Observaciones</label>
                                    <input type="text" class="form-control text-xs" id="obs<?php echo e($equipo->id); ?>" name="obs<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->observaciones); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Programas instalados</label>
                                    <input type="text" class="form-control text-xs" id="programas<?php echo e($equipo->id); ?>" name="programas<?php echo e($equipo->id); ?>" value="<?php echo e($equipo->programas_instalados); ?>" disabled>
                                  </div>
                               
                                </div>
                              </div> 
                        </form>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="tab-pane fade" id="profile">
                  <?php $__currentLoopData = $dispositivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                    
                      <form id="form2<?php echo e($dispositivos->id); ?>" name="form2<?php echo e($dispositivos->id); ?>" class="rounded" method="POST"  action="<?php echo e(route('VerAsignacionpost2',$dispositivos->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-header">
                         Dispositivos Asignados <button type="button" class="btn btn-secondary" value="<?php echo e($dispositivos->id); ?>" name="btn3<?php echo e($dispositivos->id); ?>" id="btn3<?php echo e($dispositivos->id); ?>" onclick="disable1(this.value)"><i class="fa-solid fa-unlock"></i> </button> <button type="button" class="btn btn-secondary" name="btn4<?php echo e($dispositivos->id); ?>" id="btn4<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->id); ?>" onclick="enable1(this.value)" style="display: none"><i class="fa-solid fa-lock"></i></button> <button type="submit" id="save2<?php echo e($dispositivos->id); ?>" nameid="save2<?php echo e($dispositivos->id); ?>" class="btn btn-dark" disabled><i class="fa-solid fa-pen-to-square"></i></button>
                        </div>
                        <div class="card-body">
                          
                            <div class="container text-center">
                                <div class="row">
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Estado del equipo</label>
                                    <select class="form-select"id="eqd<?php echo e($dispositivos->id); ?>" name="eqd<?php echo e($dispositivos->id); ?>" disabled>
                                      <option selected value="<?php echo e($dispositivos->estado_disp); ?>" ><?php echo e($dispositivos->estado_disp); ?></option>
                                      <option  value="REASIGNADO">REASIGNADO</option>
                                      <option  value="NUEVO">NUEVO</option>
                                    </select>
                                    
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Tipo de dispositivo</label>
                              
                                    <input type="text" class="form-control text-xs" id="tdd<?php echo e($dispositivos->id); ?>" name="tdd<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->t_dispositivo); ?>" disabled>
                                  </div>
                                 
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Marca</label>
                                    <input type="text" class="form-control text-xs" id="marcad<?php echo e($dispositivos->id); ?>" name="marcad<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->marca_disp); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Modelo</label>
                                    <input type="text" class="form-control text-xs"  id="modelod<?php echo e($dispositivos->id); ?>" name="modelod<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->modelo_disp); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Numero de serie</label>
                                    <input type="text" class="form-control text-xs" id="nseriedis<?php echo e($dispositivos->id); ?>" name="nseriedis<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->numserie_disp); ?>" disabled>
                                  </div>
                               
                                 
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">MAC</label>
                                    <input type="text" class="form-control text-xs"  id="macd<?php echo e($dispositivos->id); ?>" name="macd<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->mac_disp); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">IMEI</label>
                                    <input type="text" class="form-control text-xs"    id="imeid<?php echo e($dispositivos->id); ?>" name="imeid<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->imei_disp); ?>" disabled>
                                  </div>
                                 
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Ip del dispositivo</label>
                                    <input type="text" class="form-control text-xs"    id="ipd<?php echo e($dispositivos->id); ?>" name="ipd<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->ip_disp); ?>" disabled>
                                  </div>
                                
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Fecha de compra</label>
                                    <input type="date" class="form-control text-xs"   id="fcd<?php echo e($dispositivos->id); ?>" name="fcd<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->fecha_compra); ?>" disabled>
                                  </div>
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Fecha de asignación</label>
                                    <input type="date" class="form-control text-xs"   id="fad<?php echo e($dispositivos->id); ?>" name="fad<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->fecha_asignacion); ?>" disabled>
                                  </div>
                                  
                                  <div class="col-lg-3">
                                    <label  class="form-label text-sm">Observaciones</label>
                                    <input type="text" class="form-control text-xs"   id="obsd<?php echo e($dispositivos->id); ?>" name="obsd<?php echo e($dispositivos->id); ?>" value="<?php echo e($dispositivos->observaciones_disp); ?>" disabled>
                                  </div>            
                                </div>
                              </div> 
                        </form>
                        </div>
                       
                      </div> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="tab-pane fade" id="messages">
                    <div class="card ">
                        <div class="table-responsive  p-3" id="mydatatable-container">
                            <table class="records_list table table-striped table-bordered table-hover text-xs " id="mydatatable" cellspacing="0">
                                <thead>
                                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                                        <th class=" text-center" style="width: 30px">ID</th>
                                        <th class=" text-center">DESCRIPCION</th>
                                        <th class=" text-center">USUARIO</th>
                                        <th class=" text-center">CONTRASEÑA</th>
                                        <th class=" text-center">URL/APP</th>
                                        <th class=" text-center"style="width: 50px">CATEGORIA</th>
                                        <th class=" text-center" style="width: 30px">EDITAR</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Filter..</th>
                                         <th>Filter..</th>
                                        <th>Filter..</th>
                                        <th>Filter..</th>
                                        <th>Filter..</th>
                                        <th>Filter..</th>
                                        <th>Filter..</th>
                                    </tr>
                                </tfoot>
                                <tbody class="text-gray-600 text-xs font-light ">
                                    <?php $__currentLoopData = $password; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="text-center"><?php echo e($passw->id); ?></td>
                    <td class=" text-center"><?php echo e($passw->descripcion); ?></td>
                    <td class=" text-center"><?php echo e($passw->name); ?> <?php echo e($passw->lastname); ?></td>
                    <td class=" text-center"><?php echo e($passw->password); ?></td>
                    
                    <td class=" text-center"><?php echo e($passw->urlapp); ?></td>
                    <td class=" text-center"><?php echo e($passw->categoria); ?></td>
                    <td class=" text-center">              
                      <a>
                        <div class="flex item-center justify-center">
                          <button class="w-4 mr-2 transform hover:text-green-700 hover:scale-130" data-bs-toggle="modal" data-bs-target="#exampleModal">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                              </svg>
                          </button>
                      </div>
                    </a>   
                    </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-gradient-to-tr from-gray-500 to-gray-900  rounded-lg  text-white font-bold text-md">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Accesos</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class=" shadow p-3  rounded" method="POST" action="<?php echo e(route('contrasenas',2)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="" class="form-label">ID</label>
            <input type="text" class="form-control" id="idpw" name="idpw" readonly >
          </div>
          <div class="mb-3">
            <label for="" class="form-label">DESCRIPCION</label>
            <input type="text" class="form-control" id="descpw" name="descpw" >
          </div>
        
          <div class="mb-3">
            <label for="" class="form-label">USUARIO</label>
            <input type="text" class="form-control" id="userpw" name="userpw" readonly >
          </div>
          <div class="mb-3">
            <label for="" class="form-label">CONTRASEÑA</label>
            <input type="text" class="form-control" id="passpw" name="passpw" >
          </div>
          <div class="mb-3">
            <label for="" class="form-label">URL/APP</label>
            <input type="text" class="form-control" id="urlpw" name="urlpw" >
          </div>
          <div class="mb-3">
              <label for="" class="form-label">CATEGORIA</label>
              <input type="text" class="form-control" id="catpw" name="catpw" >
            </div>
            <div class="mb-3">
              <label for="" class="form-label">ESTATUS</label>
              <select class="form-select" name="estatusu" id="estatusu">
                <option  selected value="ACTIVO">ACTIVO</option> 
                <option value="INACTIVO">INACTIVO</option>
           
              </select>
            </div>
            
          <div class="d-flex justify-content-center"><button type="submit" class="btn shadow btn-dark">Aceptar</button></div>
          
        </form>
      </div>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAAB9CAMAAACWN3/AAAAAwFBMVEX///8AAACuyQxAQEB/f3+/v7/v7+8QEBAwMDDPz8/f399wcHAgICDC10mfn5/6/PCPj4/W5IWvr6/r8cJQUFBgYGDM3We40Cr1+OHS4Xfh66Tw9dG90zrm7rPH2ljb55T7x1380GT82GqkvQv81Iz+89/+33D+79VXZAMmLgH/+/T70IH9579sfgT6xVqYsQr+6nn94Kv97MpiZVA/SgKDlwi8yHT7zXdKVwL7yGx3iwQPEgD815b95XYzPQFVV1DSYYu2AAAJEElEQVR4nO1caWObOBA1Acxl4zuxncvpkbRNmzZ7d7fd/f//akEgaUYHRtgcIX6fklgBPTTHm5HwYHDCCSeccMJLRtj2BBrE0Ju3PYXmEFmjYdtzaAquZVlR25NoCqOErOW2PYtm4KRcX4khB1aGV2HIdk7WCtqeSf2YUq6W3/ZUakfoMbKW0/Zk6sbSAui5Ic8hV8tuezq1Yughsta07QnViRXmank9rghcS0R/DXk4kshacduTqguOzNXyeqoaAwVXy1q2Pa164CvJWr2s46dqrr00ZKgTLR/+Ylr+rBfXs9lmnOJmtl2sa5nuYbDhagZISZWv4y9vz8dnIi5mXeOL2DmYe7k6fjGTeVKcd4ou0omjgWDVew15fXujJZph0wCJskA6kZgtileF5c/l5mIP0xRXzRApAaQT83WEhqyv49ezMkyJKU8aIrMHSCfSVIM0hrqOn2yvSjJNMWuQUQEiyIuJCKQeFYa8ODdgmuCiSUpaoDUE8hCut1j+TLay+SaJ9ZxkWI1lXzbKSgOoE2EFizwZ1fHrmUBzs10gl1yownMX7NjRcorUT2GN7Hc8U6+Y7NAdSD8oo2JrHao+WsA1O78uurRg6uO6KJQH1on4M6SrSB2/GJdlmmKCjLl9M44LMwzsrCY5CVAdb0td/rZLZCWdiIFs/Ffuq5vSYheEstujzrwCUFNcUd4A1fiBTvri1kQM8TDVdupR6UQM6tK/vaVUy9kvw5qRPcaEDwDSiepKLiSfffy9ItUBN+Rzw//79Pz4+Pjus/H9dFDrRIw0DX/J5/v2jwo3uaxmxQ+7p12Cpz/fV7inAjqdiOH/RS34S7X9+EpZ9v3T7o5gt/tU4Z4ykE7U0VhQZfD1o86v9yDLV3uTMsb3hOubFHe7dxXuKUGvEzkmG2rBH7QRex+I0xrWPJ+fEq739z/v39zdPR2hEg4hV82mDlvWv//JB1bYj59VWNgfu4Trz2/fUra7IwQppBOV23VsWb/+y0ea78fPzD128JiS/ZbgZ0L22fiWIlCTScngki7r5j841ng/PiVr2l58R8neH4Ms0olK22RC77rE4CJsKijFZ2jGv5j+t4h9OnFCNf9VuiioXDDdjx+f3RhPb/KUsk2QcN0Z/7cAVLwp8smCSf7sd+jgpvvxZ2cVwulznnruDl/YfTqRmTBVhwUl/j5MqlUAP3a7TFMc7LHFOpHX3HyaZZKyGltzOU3wTNTi94MdFhU7kk68pFXZFTS/UnJLhUXlaT48PBxBGBdOnLnrGLlaOSHdPSCTFI+IbClXsSQrUyIRBNOVbdtLR6Mswyj5EN41cJbJeDuKy9lL6DoJ3JLGVagTZzqu6k0SGTE3mxHRKhbVLNkPEX7GQwdcdgXjvA0nmDwgO8CXX5VSN0Vp5FzLVfD0lfraAT6Z4QcC2aGPn7ErHEcCUg6RTX9JLGWOhpcowYp0YhFX1camCCo+fNvOWHkxJku0jD2iWhyMz3+ymckoyFJPonlQ88Q5CqQfTznqFgpuRSoMOZu7nTnfMCbTjSFZj6wue3EoHz8n44OIXN6n15XJkoe9IuEinHpl1lZ/yHbCGoE6ebdHd5GP4TtBcw/aT/YzCE2uMD604XJJZFNbsZnbDZda+yoxX871SivvUFko3ogsvI8WPPRFso44Hj1vsnZzDVnBbon7F+bAAktkNnyhl7JhUfkTKYw7+wdOFkbxNAN6Qkhd8TEKsthHiWEUZSCULNHS8HZ/kZQtiG7kOUpmFWOykTBezNckv8UasuKT9IvtWK8TOddiKYtSC1qWqfToCUaIrIvHyyWFy0xGJivqn0h64NKdKZAuYLppXy8bqUZkyEuRPefEyQrjFeuSTpFEIYmsJw51CslqdeI146oPTqprwPLHU+2MZU+HkR3h8dL0B9lyEeOWyErByFX9Ed6XAVoQ34/ZX3ti1QgEmO7OkKyN/64qjOd0vERWWkRXcwn2H6pp8qRT5igA8nt+r1BnUxqyrma8exyyKJJCA9wwrgVZhyNSXqd+spKDF5DV5kjusOVa2ShX8zBnabSqhmyoGX8csjqdOOFcS7aykQpjfuqpu6woQMGl1Mw0puZyCFnxkC0DN+Kzsh0U9NyoLkjno9AzUx1ZXz1+RWkdQFarExfGCyt4BDXkqaV0wpGObOr68ps0Q5aRDiCr1YljQ48lQLEu97yhpWpgYLkIyQaWqk502AWrk9V2GcDCmuwqqsqf9HmKXht4WrLKdEKkQAhvYU5W3z8CC2tyTgnpk3x9iKcs0VplXDVkyQJgQyZlW74WlckijQcrDaCdzBr36IoRmL0Ptb6XNyeUZDPXggmfdLDoWlQlq9WJ8EyW4d44Kn/yeeRtlilJbG7WN0RtGUdxDZuSGDrpg2EVblWyukO2gwE4Sml4dAdFAeqqcximyd1csZUKkfca/Sh2XSfPZ8yuK5LV6kR2bCeF6R4qiu+UxRC/grsMgYyUyeaNJPhwuNqpRraglwLPUZruyeA3UNkkwxW9nUfa2C57wAqyUicYhLdqZB0bAJfXQD0J8Yl8cjUuOnxKtiEo4EyCOPlDnP9lzqYpjGJ0Vzlfe4oiuXpHACJIN0308xMBX7JSf3LwudnU2vfuXgduA99lc0yy6cNXt1lUDYwWAMniAy3mnpzmGFn+pcGxI19TA19tQLRYjWtwHIJ07AW2QP61DlC34zKARi4TpUGI+YjZFKaltgEKd7zBQ7tSRkqDCCgvYnTjkZzs2gS0Y2CxTDKbHf7IdyBHdpJlVnnq8EtukTcAuLSAGBMbhsfwxL3lzgSnDEAwgtYijdLmLwvGqEBYdSQ2UVzyWoDtBjArrvJGWRhHmVhz5t2xYIoJ14w0RjFP7tS76scBf715TNgxR+7Ou9tHxfp6Mx5TacEq+tbfsWoAzIs78pp6nWB7ta2/KdgA2ML2MDyJ0B/o6x94c/UVLOzNK/JYvh3yCkLxxStaWBaduvF9IbWCR6eKbzG8JLDo1IHvlKgbfIOg7Zfx6wcv5DvwzSg1A5z96n/a4c03wzd7XyB4w6L/opgfwt17MPXFg3PtfyQGHdXeywnAtfcOCw4I9bShCDBZMPQ+OJ1wwgmdwP/W92x8A1sCMwAAAABJRU5ErkJggg=="> 
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lexend+Tera:wght@300&family=Poiret+One&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" >

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css" rel="stylesheet" >




<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.4.0/js/dataTables.fixedHeader.min.js"></script>
   <script type="text/javascript">
    $(document).ready(function () {
        $('#mydatatable tfoot th').each(function () {
            var title = $(this).text();
            $(this).html('<input type="text" class="form-control" placeholder="Filtrar.."  style="font-size: 12px;"/>');
        });

        var table = $('#mydatatable').DataTable({
              "dom": '<"float-left"B><"float-right"f>t<"float-left"i><"float-right"p><"clearfix">',
            "responsive": false,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
            },
            "order": [
                [0, "desc"]
            ],
            "initComplete": function () {
                this.api().columns().every(function () {
                    var that = this;

                    $('input', this.footer()).on('keyup change', function () {
                        if (that.search() !== this.value) {
                            that
                                .search(this.value)
                                .draw();
                        }
                    });
                })
            },
         "buttons": [
                {
                extend:    'copyHtml5',
                text:      '<i class="fa fa-copy"></i>',
                titleAttr: 'Copiar al portapapeles'
            },
            {
                extend:    'excel',
                text:      '<i class="fa fa-file-excel"></i>',
                titleAttr: 'Descargar informaci贸n en excel'
            },
            {
                extend:    'pageLength',
                text:      '<i class="fa fa-ellipsis"></i>',
                titleAttr: 'Mostrar resultados'
            }
  ],
        });
    });
</script>
<script>
  function disable(value){
 $("#form"+value+" :input").prop('disabled', false);
 $("#btn1"+value).css("display", "none"); 
 $("#btn2"+value).css("display", "");
 $("#save"+value).attr("disabled", false)
}

function enable(value){
 $("#form"+value+" :input").prop('disabled', true);
 $("#btn2"+value).css("display", "none");
 $("#btn1"+value).css("display", "");
 $("#btn1"+value).attr("disabled", false);

}

function disable1(value){
 $("#form2"+value+" :input").prop('disabled', false);
 $("#btn3"+value).css("display", "none"); 
 $("#btn4"+value).css("display", "");
 $("#save"+value).attr("disabled", false)
}

function enable1(value){
 $("#form2"+value+" :input").prop('disabled', true);
 $("#btn4"+value).css("display", "none");
 $("#btn3"+value).css("display", "");
 $("#btn3"+value).attr("disabled", false);

}
  </script>
   <script>
    $("body").on("click", "#mydatatable-container a", function(event) {
        event.preventDefault();
        idsele = $(this).attr("href");
        id= $(this).parent().parent().children("td:eq(0)").text();
        descripcion= $(this).parent().parent().children("td:eq(1)").text();
      usuario  = $(this).parent().parent().children("td:eq(2)").text();
      contra  = $(this).parent().parent().children("td:eq(3)").text();
       url = $(this).parent().parent().children("td:eq(4)").text();
      categoria  = $(this).parent().parent().children("td:eq(5)").text();
        //Cargamos en el formulario los valores del registro
        $("#idpw").val(id);
        $("#descpw").val(descripcion);
        $("#userpw").val(usuario);
        $("#passpw").val(contra);
        $("#urlpw").val(url);
        $("#catpw").val(categoria);
          
    });
  
    </script>
        
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MiPueblito\resources\views/ti/VerAsignaciones.blade.php ENDPATH**/ ?>