
<?php $__env->startSection('title', 'AGROIN'); ?>
<?php $__env->startSection('content_header'); ?>
<style>
    #mydatatable-container tfoot {
            display: table-header-group !important;
        }
        #mydatatable-container tfoot {
            display: table-header-group !important;
        }
        #mydatatable2 tfoot {
            display: table-header-group !important;
        }
        #mydatatable2 tfoot {
            display: table-header-group !important;
        }
        </style>
   Incidencias por Asignar
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('alert-' . $msg)): ?>
   
    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> 

            <div class="table-responsive bg-white p-4 rounded" id="mydatatable-container">
                <table class="records_list table table-striped text-sm table-bordered table-hover" id="mydatatable">
                    <thead>
                        <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                            <th class="">FOLIO</th>
                            <th class="">USUARIO</th>
                            <th class="">PRIORIDAD</th>
                            <th class="">INCIDENCIA</th>
                            <th class="">DESCRIPCION</th>-
                             <th class="">DEPARTAMENTO</th>
                              <th class="">IMAGEN</th>
                            <th class="">FECHA</th>
                            <th class="">ASIGNAR</th>
                     </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Filter..</th>
                            <th>Filter..</th>
                            <th>Filter..</th>
                            <th>Filter..</th>
                            <th>Filter..</th>
                            <th>Filter..</th>
                            <th>Filter..</th>
                              <th>Filter..</th>
                            <th>Filter..</th>
                       
                        </tr>
                    </tfoot>
                    <tbody class="text-gray-600 text-sm font-light">
                        <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-100">

                            <td class="">
                                <div class="flex items-center">
                                  
                                    <span class="font-light"><?php echo e($incidencias->id); ?></span>
                                </div>
                            </td>

                            <td class="">
                                <div class="flex items-center">
                                  
                                    <span class="font-light"><?php echo e($incidencias->username); ?></span>
                                </div>
                            </td>
                            <?php if($incidencias->prioridad =="ALTA"): ?>
                            <td class="text-center">
            <span class="rounded bg-red-400 py-1 px-3 text-xs font-bold"><?php echo e($incidencias->prioridad); ?></span>
                            </td>
                                <?php endif; ?>
                                <?php if($incidencias->prioridad =="MEDIA"): ?>
                                <td class="text-center">
                                        <span class="rounded bg-yellow-400 py-1 px-3 text-xs font-bold"><?php echo e($incidencias->prioridad); ?></span>
                                </td>
                                    <?php endif; ?>
                                    <?php if($incidencias->prioridad =="BAJA"): ?>
                                    <td class="text-center">
          <span class="rounded bg-blue-400 py-1 px-3 text-xs font-bold"><?php echo e($incidencias->prioridad); ?></span>
                                    </td>
                                        <?php endif; ?>

                            <td class="">
                                <div class="flex items-center">
                                  
                                    <span class="font-light"><?php echo e($incidencias->t_incidencia); ?></span>
                                </div>
                            </td>
                            <td class=" text-left">
                                <div class="flex items-center">
                                  
                                    <span class="font-light"><?php echo e($incidencias->descripcion); ?></span>
                                </div>
                            </td>
                            <td class=" text-left">
                                <div class="flex items-center">
                                  
                                    <span class="font-light"><?php echo e($incidencias->dto); ?></span>
                                </div>
                            </td>
                            <td class=" text-left">
                                <div class="flex items-center">
                                    <?php if($incidencias->imagen =="" || $incidencias->imagen==NULL): ?>
                                    <span class="font-light"><p>Sin evidencia</p></span> 
                                    <?php else: ?>
                                    <span class="font-light"><button type="button" onclick="window.open('<?php echo e(route('ImgIncidencia',$incidencias->id)); ?>', '_blank')"   ><p style="color: rgb(7, 101, 251);">Imagen</p></button></span>
                                    <?php endif; ?>
                                 
                                </div>
                            </td>
                            <td class="">
                                <div class="flex items-center">
                                  
                                    <span class="font-light"><?php echo e($incidencias->created_at); ?></span>
                                </div>
                            </td>
                            <td class="">
                                  <a class="btn btn-light" href="" name="idsele" data-toggle="modal" data-target="#exampleModal" role="tab">
                                    <i class="fa fa-cogs"></i>
                                  </a>
                            </td>

                           
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
         
         <p class="m-2">Incidencias Asignadas</p>
         <div class="table-responsive bg-white p-4 rounded" id="mydatatable2-container">
            <table class="records_list table table-striped table-bordered table-hover" id="mydatatable2">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="">FOLIO</th>
                        <th class="">USUARIO</th>
                          <th class="">DTO</th>
                        <th class="">PRIORIDAD</th>
                        <th class="">INCIDENCIA</th>
                        <th class="">DESCRIPCION</th>
                          <th class="">IMAGEN</th>
                        <th class="">FECHA</th>
                        <th class="">ASIGNADO</th>
                        <th class="">SETTINGS</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                         <th>Filter..</th>
                        <th>Filter..</th>
                    </tr>
                </tfoot>
                <tbody class="text-gray-600 text-sm font-light">
                    <?php $__currentLoopData = $incidenciasasignadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-100">

                        <td class="">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($asig->id); ?></span>
                            </div>
                        </td>

                        <td class="">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($asig->username); ?></span>
                            </div>
                        </td>
                          <td class="">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($asig->dto); ?></span>
                            </div>
                        </td>
                        <?php if($asig->prioridad =="ALTA"): ?>
                        <td class=" text-center">
     <span class="rounded bg-red-400  text-center  text-xs font-bold"><?php echo e($asig->prioridad); ?></span>   
                        </td>
                            <?php endif; ?>
                            <?php if($asig->prioridad =="MEDIA"): ?>
                            <td class=" text-center">
     <span class="rounded bg-yellow-400 py-1 px-3 text-xs font-bold"><?php echo e($asig->prioridad); ?></span>  
                            </td>
                                <?php endif; ?>
                                <?php if($asig->prioridad =="BAJA"): ?>
                                <td class="text-center">
     <span class="rounded bg-blue-400 py-1 text-center px-3 text-xs font-bold"><?php echo e($asig->prioridad); ?></span>  
                                </td>
                                    <?php endif; ?>

                        <td class="">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($asig->t_incidencia); ?></span>
                            </div>
                        </td>
                        <td class=" ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($asig->descripcion); ?></span>
                            </div>
                        </td>
                            <td class="">
                                <div class="flex items-center">
                                    <?php if($asig->imagen =="" || $asig->imagen==NULL): ?>
                                    <span class="font-light"><p>Sin evidencia</p></span> 
                                    <?php else: ?>
                                    <span class="font-light"><button type="button" onclick="window.open('<?php echo e(route('ImgIncidencia',$asig->id)); ?>', '_blank')"   ><p style="color: rgb(7, 101, 251);">Imagen</p></button></span>
                                    <?php endif; ?>
                                 
                                </div>
                            </td>
                        <td class="">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($asig->created_at); ?></span>
                            </div>
                        </td>
                        <td class="">
                            <div class="flex items-center">
                                <span class="font-light"><?php echo e($asig->asignado); ?></span>
                            </div>
                        </td>

                        <td class="">
                              <a class="btn btn-light" href="" name="idsele" data-toggle="modal" data-target="#exampleModala" role="tab">
                                <i class="fa fa-cogs"></i>
                              </a>
                        </td>
                        
                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
      
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
           
            </div>
            <div class="modal-body">
              <form method="POST"  action="<?php echo e(route('Asignar')); ?>">
                <?php echo csrf_field(); ?>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
     <button class="btn btn-danger me-md-2" type="button" id="banear" onclick="baner()"><i class="fa fa-solid fa-ban"></i></button>   </div>
                <!---->
                
                <input type="hidden" id="idt" name="idt">
                <div class="col-sm-12 col-md-12 col-lg-12 mb-3">
                    <label for="exampleInputEmail1" class="form-label">Asignar a Usuario:</label>
                    <select class="form-select js-example-basic-multiple" name="user" id="user"  required>
                      <option selected disabled>Selecciona el usuario</option>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($user->name); ?>"> <?php echo e(strtoupper($user->name)); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            
                <div class="mt-4 d-flex justify-content-center">
                  <button type="submit" class="btn btn-dark">GUARDAR</button>                 
                </div>
              </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal  asignacion completada-->
<div class="modal fade" id="exampleModala" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered " role="document">
        <div class="modal-content">
            <div class="modal-header">
           
            </div>
            <div class="modal-body">
              <form method="POST"  action="<?php echo e(route('CompletarSoporte')); ?>">
                <?php echo csrf_field(); ?>
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
     <button class="btn btn-danger me-md-2" type="button" id="banear" onclick="baner()"><i class="fa fa-solid fa-ban"></i></button>   </div>
                <div class="col-sm-12 col-md-12 col-lg-12 mb-4">
                    <label for="exampleInputEmail1" class="form-label">FOLIO</label>
                    <input type="text" class="form-control" id="folio" name="folio" readonly>
                  </div>
                  <div class="col-sm-12 col-md-12 col-lg-12 mb-3">
                    <label for="exampleInputEmail1" class="form-label">CLASIFICACION</label>
                    <select class="form-select js-example-basic-multiple" name="clasificacion" id="clasificacion"  required>
                      <option selected disabled>Selecciona una opcion</option>
              <option  value="Equipo nuevo o reasignación">Equipo nuevo o reasignación</option>
              <option  value="Soporte general de equipos">Soporte general de equipos</option>
              <option  value="Acceso a aplicaciones">Acceso a aplicaciones</option>
              <option  value="Acceso a internet">Acceso a internet</option>
               <option  value="Telefonía fija">Telefonía fija</option>
                <option  value="Cámaras de vigilancia">Cámaras de vigilancia</option>
             
                    </select>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-12 mb-4">
                    <label for="exampleInputEmail1" class="form-label">SOLUCION PLANTEADA</label>
                    <textarea class="form-control"  id="obs" name="obs" required></textarea>
                  </div>
                  <!---->
                   <div class="col-sm-12 col-md-12 col-lg-12 mb-4">
                    <label for="exampleInputEmail1" class="form-label">FECHA</label>
                    <input type="text" name="datetimes" id="datetimes" class="form-control"  />
                  </div>
                  <!---->
                  <!--<div class="col-sm-12 col-md-12 col-lg-12 mb-4">-->
                  <!--  <label for="exampleInputEmail1" class="form-label">FECHA Y HORA DE COMIENZO</label>-->
                  <!--  <input type="datetime-local" class="form-control" id="fin" name="fin" required>-->
                  <!--</div>-->
                  <!--<div class="col-sm-12 col-md-12 col-lg-12 mb-4">-->
                  <!--  <label for="exampleInputEmail1" class="form-label">FECHA Y HORA DE FINALIZACION</label>-->
                  <!--  <input type="datetime-local" class="form-control" id="empieso" name="empieso" required>-->
                  <!--</div>-->
                <div class="mt-4 d-flex justify-content-center">
                  <button type="submit" class="btn btn-dark">GUARDAR</button>                 
                </div>
              </form>
            </div>
        </div>
    </div>
</div>
   <form method="POST"  action="<?php echo e(route('Cancelar')); ?>" id="fcancel" style="display:none">
                <?php echo csrf_field(); ?>
     
                <!---->
                
                <input type="text" id="idtx" name="idtx">
               
            
                <div class="mt-4 d-flex justify-content-center">
                  <button type="submit" class="btn btn-dark">GUARDAR</button>                 
                </div>
              </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAAB9CAMAAACWN3/AAAAAwFBMVEX///8AAACuyQxAQEB/f3+/v7/v7+8QEBAwMDDPz8/f399wcHAgICDC10mfn5/6/PCPj4/W5IWvr6/r8cJQUFBgYGDM3We40Cr1+OHS4Xfh66Tw9dG90zrm7rPH2ljb55T7x1380GT82GqkvQv81Iz+89/+33D+79VXZAMmLgH/+/T70IH9579sfgT6xVqYsQr+6nn94Kv97MpiZVA/SgKDlwi8yHT7zXdKVwL7yGx3iwQPEgD815b95XYzPQFVV1DSYYu2AAAJEElEQVR4nO1caWObOBA1Acxl4zuxncvpkbRNmzZ7d7fd/f//akEgaUYHRtgcIX6fklgBPTTHm5HwYHDCCSeccMJLRtj2BBrE0Ju3PYXmEFmjYdtzaAquZVlR25NoCqOErOW2PYtm4KRcX4khB1aGV2HIdk7WCtqeSf2YUq6W3/ZUakfoMbKW0/Zk6sbSAui5Ic8hV8tuezq1Yughsta07QnViRXmank9rghcS0R/DXk4kshacduTqguOzNXyeqoaAwVXy1q2Pa164CvJWr2s46dqrr00ZKgTLR/+Ylr+rBfXs9lmnOJmtl2sa5nuYbDhagZISZWv4y9vz8dnIi5mXeOL2DmYe7k6fjGTeVKcd4ou0omjgWDVew15fXujJZph0wCJskA6kZgtileF5c/l5mIP0xRXzRApAaQT83WEhqyv49ezMkyJKU8aIrMHSCfSVIM0hrqOn2yvSjJNMWuQUQEiyIuJCKQeFYa8ODdgmuCiSUpaoDUE8hCut1j+TLay+SaJ9ZxkWI1lXzbKSgOoE2EFizwZ1fHrmUBzs10gl1yownMX7NjRcorUT2GN7Hc8U6+Y7NAdSD8oo2JrHao+WsA1O78uurRg6uO6KJQH1on4M6SrSB2/GJdlmmKCjLl9M44LMwzsrCY5CVAdb0td/rZLZCWdiIFs/Ffuq5vSYheEstujzrwCUFNcUd4A1fiBTvri1kQM8TDVdupR6UQM6tK/vaVUy9kvw5qRPcaEDwDSiepKLiSfffy9ItUBN+Rzw//79Pz4+Pjus/H9dFDrRIw0DX/J5/v2jwo3uaxmxQ+7p12Cpz/fV7inAjqdiOH/RS34S7X9+EpZ9v3T7o5gt/tU4Z4ykE7U0VhQZfD1o86v9yDLV3uTMsb3hOubFHe7dxXuKUGvEzkmG2rBH7QRex+I0xrWPJ+fEq739z/v39zdPR2hEg4hV82mDlvWv//JB1bYj59VWNgfu4Trz2/fUra7IwQppBOV23VsWb/+y0ea78fPzD128JiS/ZbgZ0L22fiWIlCTScngki7r5j841ng/PiVr2l58R8neH4Ms0olK22RC77rE4CJsKijFZ2jGv5j+t4h9OnFCNf9VuiioXDDdjx+f3RhPb/KUsk2QcN0Z/7cAVLwp8smCSf7sd+jgpvvxZ2cVwulznnruDl/YfTqRmTBVhwUl/j5MqlUAP3a7TFMc7LHFOpHX3HyaZZKyGltzOU3wTNTi94MdFhU7kk68pFXZFTS/UnJLhUXlaT48PBxBGBdOnLnrGLlaOSHdPSCTFI+IbClXsSQrUyIRBNOVbdtLR6Mswyj5EN41cJbJeDuKy9lL6DoJ3JLGVagTZzqu6k0SGTE3mxHRKhbVLNkPEX7GQwdcdgXjvA0nmDwgO8CXX5VSN0Vp5FzLVfD0lfraAT6Z4QcC2aGPn7ErHEcCUg6RTX9JLGWOhpcowYp0YhFX1camCCo+fNvOWHkxJku0jD2iWhyMz3+ymckoyFJPonlQ88Q5CqQfTznqFgpuRSoMOZu7nTnfMCbTjSFZj6wue3EoHz8n44OIXN6n15XJkoe9IuEinHpl1lZ/yHbCGoE6ebdHd5GP4TtBcw/aT/YzCE2uMD604XJJZFNbsZnbDZda+yoxX871SivvUFko3ogsvI8WPPRFso44Hj1vsnZzDVnBbon7F+bAAktkNnyhl7JhUfkTKYw7+wdOFkbxNAN6Qkhd8TEKsthHiWEUZSCULNHS8HZ/kZQtiG7kOUpmFWOykTBezNckv8UasuKT9IvtWK8TOddiKYtSC1qWqfToCUaIrIvHyyWFy0xGJivqn0h64NKdKZAuYLppXy8bqUZkyEuRPefEyQrjFeuSTpFEIYmsJw51CslqdeI146oPTqprwPLHU+2MZU+HkR3h8dL0B9lyEeOWyErByFX9Ed6XAVoQ34/ZX3ti1QgEmO7OkKyN/64qjOd0vERWWkRXcwn2H6pp8qRT5igA8nt+r1BnUxqyrma8exyyKJJCA9wwrgVZhyNSXqd+spKDF5DV5kjusOVa2ShX8zBnabSqhmyoGX8csjqdOOFcS7aykQpjfuqpu6woQMGl1Mw0puZyCFnxkC0DN+Kzsh0U9NyoLkjno9AzUx1ZXz1+RWkdQFarExfGCyt4BDXkqaV0wpGObOr68ps0Q5aRDiCr1YljQ48lQLEu97yhpWpgYLkIyQaWqk502AWrk9V2GcDCmuwqqsqf9HmKXht4WrLKdEKkQAhvYU5W3z8CC2tyTgnpk3x9iKcs0VplXDVkyQJgQyZlW74WlckijQcrDaCdzBr36IoRmL0Ptb6XNyeUZDPXggmfdLDoWlQlq9WJ8EyW4d44Kn/yeeRtlilJbG7WN0RtGUdxDZuSGDrpg2EVblWyukO2gwE4Sml4dAdFAeqqcximyd1csZUKkfca/Sh2XSfPZ8yuK5LV6kR2bCeF6R4qiu+UxRC/grsMgYyUyeaNJPhwuNqpRraglwLPUZruyeA3UNkkwxW9nUfa2C57wAqyUicYhLdqZB0bAJfXQD0J8Yl8cjUuOnxKtiEo4EyCOPlDnP9lzqYpjGJ0Vzlfe4oiuXpHACJIN0308xMBX7JSf3LwudnU2vfuXgduA99lc0yy6cNXt1lUDYwWAMniAy3mnpzmGFn+pcGxI19TA19tQLRYjWtwHIJ07AW2QP61DlC34zKARi4TpUGI+YjZFKaltgEKd7zBQ7tSRkqDCCgvYnTjkZzs2gS0Y2CxTDKbHf7IdyBHdpJlVnnq8EtukTcAuLSAGBMbhsfwxL3lzgSnDEAwgtYijdLmLwvGqEBYdSQ2UVzyWoDtBjArrvJGWRhHmVhz5t2xYIoJ14w0RjFP7tS76scBf715TNgxR+7Ou9tHxfp6Mx5TacEq+tbfsWoAzIs78pp6nWB7ta2/KdgA2ML2MDyJ0B/o6x94c/UVLOzNK/JYvh3yCkLxxStaWBaduvF9IbWCR6eKbzG8JLDo1IHvlKgbfIOg7Zfx6wcv5DvwzSg1A5z96n/a4c03wzd7XyB4w6L/opgfwt17MPXFg3PtfyQGHdXeywnAtfcOCw4I9bShCDBZMPQ+OJ1wwgmdwP/W92x8A1sCMwAAAABJRU5ErkJggg=="> 
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://demos.creative-tim.com/notus-js/assets/styles/tailwind.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lexend+Tera:wght@300&family=Poiret+One&display=swap" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link type="text/css" href="//gyrocode.github.io/jquery-datatables-checkboxes/1.2.12/css/dataTables.checkboxes.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" >

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css" rel="stylesheet" >
<!--piker-->
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.4.0/js/dataTables.fixedHeader.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     <!--pikers-->
    <!--<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>-->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
      <script>
        $(function() {
          $('input[name="datetimes"]').daterangepicker({
            timePicker: true,
            showDropdowns: true,
        drops: "up",
        timePicker24Hour: true,
            locale: {
              format: 'YYYY-MM-DD hh:mm '
            }
          });
        });
        </script>
  
    <script>
        $("body").on("click", "#mydatatable a", function(event) {
            event.preventDefault();
            idsele = $(this).attr("href");
            id= $(this).parent().parent().children("td:eq(0)").text();
        
            //Cargamos en el formulario los valores del registro
        
            $("#idt").val(id);
              $("#idtx").val(id);
            eliminaEspacio();
        });
        function eliminaEspacio(){
    
    $('input').val(function(_, value) {
    return $.trim(value);
    });
    
    }
        </script>
         <script>
            $("body").on("click", "#mydatatable2 a", function(event) {
                event.preventDefault();
                idsele = $(this).attr("href");
                id= $(this).parent().parent().children("td:eq(0)").text();
                //Cargamos en el formulario los valores del registro
                $("#folio").val(id);
                   $("#idtx").val(id);
                eliminaEspacio();
            });
          
            </script>
   <script type="text/javascript">
    $(document).ready(function () {
        $('#mydatatable tfoot th').each(function () {
            var title = $(this).text();
            $(this).html('<input type="text" class="form-control" placeholder="Filtrar.."  style="font-size: 12px;"/>');
        });

        var table = $('#mydatatable').DataTable({
            "dom": 'B<"float-left"><"float-right"f>t<"float-left"l><"float-right"p><"clearfix">',
            "responsive": false,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
            },
            "order": [
                [0, "desc"]
            ],
            "initComplete": function () {
                this.api().columns().every(function () {
                    var that = this;

                    $('input', this.footer()).on('keyup change', function () {
                        if (that.search() !== this.value) {
                            that
                                .search(this.value)
                                .draw();
                        }
                    });
                })
            },
            "buttons": [
                {
                extend:    'copyHtml5',
                text:      '<i class="fa fa-copy"></i>',
                titleAttr: 'Copiar al portapapeles'
            },
            {
                extend:    'excel',
                text:      '<i class="fa fa-file-excel"></i>',
                titleAttr: 'Descargar informaci贸n en excel'
            },
            {
                extend:    'pageLength',
                text:      '<i class="fa fa-ellipsis"></i>',
                titleAttr: 'Mostrar resultados'
            }
  ],
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#mydatatable2 tfoot th').each(function () {
            var title = $(this).text();
            $(this).html('<input type="text" class="form-control" placeholder="Filtrar.."  style="font-size: 8px;"/>');
        });

        var table = $('#mydatatable2').DataTable({
            "dom": 'B<"float-left"><"float-right"f>t<"float-left"l><"float-right"p><"clearfix">',
            "responsive": false,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
            },
            "order": [
                [2, "asc"]
            ],
            "initComplete": function () {
                this.api().columns().every(function () {
                    var that = this;

                    $('input', this.footer()).on('keyup change', function () {
                        if (that.search() !== this.value) {
                            that
                                .search(this.value)
                                .draw();
                        }
                    });
                })
            },
            "buttons": [
                {
                extend:    'copyHtml5',
                text:      '<i class="fa fa-copy"></i>',
                titleAttr: 'Copiar al portapapeles'
            },
            {
                extend:    'excel',
                text:      '<i class="fa fa-file-excel"></i>',
                titleAttr: 'Descargar informaci贸n en excel'
            },
            {
                extend:    'pageLength',
                text:      '<i class="fa fa-ellipsis"></i>',
                titleAttr: 'Mostrar resultados'
            }
  ],
        });
    });
</script>
<script>
function baner()
{
 Swal.fire({
  title: 'Estás seguro de cancelar la solicitud?',
  text: "...",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Aceptar',
    cancelButtonText: 'Cancelar',
}).then((result) => {
  if (result.isConfirmed) {
     var selectedForm=document.getElementById("fcancel");
  selectedForm.submit();
  }
})   
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agroin\resources\views/ti/Incidencias.blade.php ENDPATH**/ ?>