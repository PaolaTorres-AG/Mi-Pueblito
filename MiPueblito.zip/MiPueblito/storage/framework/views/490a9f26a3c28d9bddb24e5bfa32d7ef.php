<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('TI')): ?>

<?php $__env->startSection('title', 'Mi Pueblito'); ?>
<?php $__env->startSection('content_header'); ?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap');
  * {
  padding: 0;
  margin: 0;
  font-family: 'Poppins', sans-serif;
  }
     </style>
     <p style="font-weight: bold;color:#f2ca28; text-align: right;">¡BIENVENIDO <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?> !</p>

   <div class="card   " >
    <div class="card-header">
     Consultar incidencias
    </div>
    <div class="card-body">
        <form class="bg-white p-4 rounded" method="POST"  action="<?php echo e(route('IncidenciasFiltro')); ?>" >
            <?php echo csrf_field(); ?>
        <div class="container">
            <div class="row">
              <div class="col">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">De:</label>
                    <input type="date" class="form-control" id="de" name="de" required>
                  </div>
              </div>
              <div class="col">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Hasta:</label>
                    <input type="date" class="form-control" id="hasta" name="hasta" required >
                  </div>
              </div>
              
            </div>
          </div>
          
          <div class="d-flex justify-content-center"><button type="submit" class="btn btn-dark">Consultar</button></div>
          
          
      </form>
    </div>
  </div>
   <div  class="pageLoader" id="pageLoader"></div>
   <style>
     .pageLoader{
    background: url(https://www.villapoliti.com/images/loading.gif) no-repeat center center;
    position: fixed;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    z-index: 9999999;
    background-color: #ffffff8c;
}

   </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container col-12">
      <div class="row col-12">

  <div class="col-sm-12 col-md-6 col-lg-5 mb-4">
    <figure class="highcharts-figure">
        <div id="container"></div>
     
      </figure>
 </div>
   
  <div class="col-sm-12 col-md-6 col-lg-7 mb-4">
    <figure class="highcharts-figure">
        <div id="container2"></div>
     
      </figure>
  </div>
  
   
    </div>
  </div>


<div class="container col-12">
    <div class="row col-12">

<div class="col-sm-12 col-md-6 col-lg-5 mb-4">
            <!-- Table -->
            <div class="w-full max-w-2xl mx-auto bg-white shadow-lg rounded-sm border border-gray-200">
                <header class="px-1 py-2 border-b border-gray-100">
                    <p class="font-semibold text-gray-800">Soportes Sistemas</p>
                </header>
                <div class="">
                    <div class="overflow-x-auto">
                        <table class="table-auto w-full">
                            <thead class="text-xs font-light uppercase text-gray-400 bg-gray-50">
                                <tr>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-light text-left">Sistemas TI</div>
                                    </th>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-light text-left">Total Soportes</div>
                                    </th>
                                    <th class="p-2 whitespace-nowrap">
                                        <div class="font-light text-left">Tiempo Invertido (HORAS)</div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-sm divide-y divide-gray-100">
                               <?php $__currentLoopData = $users2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td class=" p-2 font-light text-center">
                                    
                                       <?php echo e($users2->asignado); ?>

                                    
                                </td>
                                <td class="p-2 font-light text-center">
                                      <?php echo e($users2->tot); ?>

                                </td>
                                <td class="p-2 font-light text-center">
                                  <?php echo e(number_format($users2->tim/60, 2)); ?>

                                </td>
                              
                            </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        
</div>
 
<div class="col-sm-12 col-md-6 col-lg-7 mb-4">
  <!-- Table -->
  <div class="w-full max-w-2xl mx-auto bg-white shadow-lg rounded-sm border border-gray-200">
    <header class="px-1 py-2 border-b border-gray-100">
        <p class="font-semibold text-gray-800">Soportes por Incidencia</p>
    </header>
    <div class="">
        <div class="overflow-x-auto">
            <table class="table-auto w-full">
                <thead class="text-xs font-semibold uppercase text-gray-400 bg-gray-50">
                    <tr>
                        <th class="p-2 whitespace-nowrap">
                            <div class="font-semibold text-left">Incidencia</div>
                        </th>
                        <th class="p-2 whitespace-nowrap">
                            <div class="font-semibold text-left">Total</div>
                        </th>
                        <th class="p-2 whitespace-nowrap">
                            <div class="font-semibold text-left">Tiempo Invertido (MINUTOS)</div>
                        </th>
                        <th class="p-2 whitespace-nowrap">
                            <div class="font-semibold text-left">Tiempo Invertido (HORAS)</div>
                        </th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                   <?php $__currentLoopData = $incidencias2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencias2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td class="font-light p-2  text-left">
                            
                                <?php echo e($incidencias2->t_incidencia); ?>

                         
                        </td>
                        <td class="font-light text-center">
                            <?php echo e($incidencias2->tot); ?>

                       
                        <td class="font-light text-center">
                           <?php echo e($incidencias2->tiempo); ?>

                        </td>
                        <td class="font-light text-center">
                           <?php echo e(number_format($incidencias2->tiempo/60, 2)); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-light text-left">
                           TOTALES
                        </td>
                        <td class="font-light text-left">
                            TOTAL: <?php echo e($incidencias3->tot2); ?>

                         </td>
                         <td class="font-light text-center">
                            TOTAL: <?php echo e($incidencias3->tiempo2); ?>

                         </td>
                         <td class="font-light text-left">
                            TOTAL: <?php echo e(number_format($incidencias3->tiempo2/60, 2)); ?>

                         </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
</div>

 
  </div>
</div>
  
  
<?php $__env->stopSection(); ?>


  
<?php $__env->startSection('css'); ?>
<link rel="icon" href="http://mipueblitofoods.net/public/images/icono.png"> 
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://demos.creative-tim.com/notus-js/assets/styles/tailwind.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lexend+Tera:wght@300&family=Poiret+One&display=swap" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link type="text/css" href="//gyrocode.github.io/jquery-datatables-checkboxes/1.2.12/css/dataTables.checkboxes.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" >

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css" rel="stylesheet" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  
   <!-- Buttons -->
   
   <script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
   <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.53/build/pdfmake.min.js"></script>
   <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.53/build/vfs_fonts.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
 <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<script>
  $(window).on('beforeunload', function(){
    $('#pageLoader').show();
});
$(function () {
    $('#pageLoader').hide();
})
</script>
<script>
    $("body").on("click", "#sample_data a", function(event) {
        event.preventDefault();
        idsele = $(this).attr("href");
       
        id= $(this).parent().parent().children("td:eq(0)").text();
        nameup=  $(this).parent().parent().children("td:eq(1)").text();
            areaup = $(this).parent().parent().children("td:eq(2)").text();
            
           puestoup = $(this).parent().parent().children("td:eq(3)").text();
        //Cargamos en el formulario los valores del registro
        $("#idup").val(id);
        $("#nameup").val(nameup);
        $("#areaup").val(areaup);
        $("#puestoup").val(puestoup);
        $("#idt").val(id);
 
    });
    </script>
  
     
      
 <script>

    
     Highcharts.chart('container', {
    chart: {
        type: 'column',
        backgroundColor:'#ADAFA9 ',
            
    },
    title: {
        text: 'SOPORTES'
    },
    subtitle: {
        text: 'Soportes del mes realizados por usuarios'
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'SOPORTES'
        }
    },
    legend: {
        enabled: false
    },
    
    series: [{
        name: 'Soportes Finalizados',
        data: <?= $datos ?>,
        color: '#81ED11',
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',    

            align: 'right',
          //  format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif',
               
            }
        }
    },
    {
        name: 'Soportes Pendientes',
        data: <?= $datosp ?>,
        color: '#EEF606',
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
          //  format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
  
    // {
    //     name: 'Soportes Atrazados',
    //     data: <?= $datosa ?>,
    //     color: '#F60F06',
    //     dataLabels: {
    //         enabled: true,
    //         rotation: -90,
    //         color: '#FFFFFF',
    //         align: 'right',
    //       //  format: '{point.y:.1f}', // one decimal
    //         y: 10, // 10 pixels down from the top
    //         style: {
    //             fontSize: '13px',
    //             fontFamily: 'Verdana, sans-serif'
    //         }
    //     }
    // }
]
});
     </script>
  
  
        <script>
 
    
     Highcharts.chart('container2', {
    chart: {
        type: 'column',
        backgroundColor:'#ADAFA9 ',
            
    },
    title: {
        text: 'SOPORTES'
    },
    subtitle: {
        text: 'Soportes del mes realizados por tipo de incidencia'
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            }
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'SOPORTES'
        }
    },
    legend: {
        enabled: false
    },
    
    series: [{
        name: 'Soportes Solicitados',
        data: <?= $datosi ?>,
        color: '#177EE5',
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',    

            align: 'right',
          //  format: '{point.y:.1f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif',
               
            }
        }
    },
]
});
     </script>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/agroinbi/public_html/resources/views/ti/IncidenciasGraficas.blade.php ENDPATH**/ ?>