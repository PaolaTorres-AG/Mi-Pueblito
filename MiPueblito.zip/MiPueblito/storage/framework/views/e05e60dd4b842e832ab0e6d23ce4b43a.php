<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('TI')): ?>

<?php $__env->startSection('title', 'Mi Pueblito'); ?>
<?php $__env->startSection('content_header'); ?>
   <style>
         @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap');
* {
padding: 0;
margin: 0;
font-family: 'Poppins', sans-serif;
}
table.dataTable td {
  font-size: 1em;
}
#mydatatable tfoot {
            display: table-header-group !important;
        }
        
   </style>
<?php $__env->stopSection(); ?>
<p style="font-weight: bold;color:#f2ca28; text-align: right;">¡BIENVENIDO <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?> !</p>
     
<?php $__env->startSection('content'); ?>
    <div class="container col-12">
  <div class="row col-12">

  <div class="col-sm-12 col-md-4 col-lg-4 mb-4">
    <figure class="highcharts-figure">
        <div id="container"></div>
      </figure>
 </div>
 <div class="col-sm-12 col-md-4 col-lg-4 mb-4">
    <figure class="highcharts-figure">
        <div id="container2"></div>
      </figure>
 </div>
  <div class="col-sm-12 col-md-4 col-lg-4 mb-4">
    <figure class="highcharts-figure">
        <div id="container3"></div>
      </figure>
 </div>
    </div>
  </div>

<div class="card">
    <h5 class="card-header">Lista de equipos </h5>
    <div class="card-body">
        <div class="table-responsive" id="mydatatable-container">
            <table class="records_list table table-striped table-bordered table-hover" id="mydatatable">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                          <th class="py-3 px-6 text-left">ID</th>
                        <th class="py-3 px-6 text-left">USUARIO</th>
                        <th class="py-3 px-6 text-left">NOMBRE EQUIPO</th>
                        <th class="py-3 px-6 text-left">IP</th>
                           <th class="py-3 px-6 text-center">MAC</th>
                              <th class="py-3 px-6 text-center">PROCESADOR</th>
                        <th class="py-3 px-6 text-center">MEMORIA</th>
                        <th class="py-3 px-6 text-center">DISCO</th>
                         <th class="py-3 px-6 text-center">OFFICE</th>
                        <th class="py-3 px-6 text-center">ESTADO</th>
                   
                        <th class="py-3 px-6 text-center">OBSERVACIONES</th>
                         <th class="py-3 px-6 text-center">EDITAR</th>
                        
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                        <th>Filter..</th>
                       <th>Filter..</th>
                        <th>Filter..</th>
                          <th>Filter..</th>
            
                    </tr>
                </tfoot>
                <tbody class="text-gray-600 text-sm font-light ">
                    <?php $__currentLoopData = $def; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $def): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                         <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->eid); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->name); ?> <?php echo e($def->lastname); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left">
                            <div class="flex items-center">
                                <span class="font-light"><?php echo e($def->nombre_disp); ?></span>
                            </div>
                        </td>
                           <td class="py-3 px-6 text-left">
                            <div class="flex items-center">
                                <span class="font-light"><?php echo e($def->ip); ?></span>
                            </div>
                        </td>
                         <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->mac); ?></span>
                            </div>
                        </td>
                         <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->proc_velocidad); ?></span>
                            </div>
                        </td>
                        
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->memoria); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->disco); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                                <span class="font-light"><?php echo e($def->v_office); ?></span>
                            </div>
                        </td>
                               <?php if($def->identificar=="MALO"): ?>
                            <td class="py-3 text-center">
                                <span class="font-light  rounded-md text-xs bg-red-200 p-2"><?php echo e($def->identificar); ?></span>     
                        </td>
                        <?php elseif($def->identificar=="REGULAR"): ?>
                          <td class="py-3  text-center ">
                                <span class="font-light  bg-yellow-200 rounded-md text-xs p-2"><?php echo e($def->identificar); ?></span>
                        </td>
                        <?php elseif($def->identificar=="BUENO"): ?>
                          <td class="py-3  text-center ">
    <span class="font-light  rounded-md text-xs p-2 bg-blue-200"><?php echo e($def->identificar); ?></span>   
                        </td>
                        <?php else: ?>
                         <td class="py-3  text-center "> 
                                <span class="font-light  rounded-md text-xs p-2 bg-blue-200">SIN PROPIEDAD</span>
                        </td>
                            <?php endif; ?>
                      
                      
                         <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($def->obs_equipo); ?></span>
                            </div>
                        </td>
                          <td class="py-3 px-6 text-left whitespace-nowrap d-flex justify-content-center">
                                  <a class="btn btn-light" href="" name="idsele" data-toggle="modal" data-target="#exampleModal" role="tab">
                                    <i class="fa fa-cogs"></i>
                                  </a>
                            </td>
                          
                          
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <!--disp-->
                      <?php $__currentLoopData = $disp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                         <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light">D-<?php echo e($disp->disp); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($disp->name); ?> <?php echo e($disp->lastname); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left">
                            <div class="flex items-center">
                                <span class="font-light"><?php echo e($disp->t_dispositivo); ?></span>
                            </div>
                        </td>
                           <td class="py-3 px-6 text-left">
                            <div class="flex items-center">
                                <span class="font-light"><?php echo e($disp->ip_disp); ?></span>
                            </div>
                        </td>
                           <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($disp->mac_disp); ?></span>
                            </div>
                        </td>
                           <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($disp->marca_disp); ?></span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light">NA</span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light">NA</span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                                <span class="font-light">NA</span>
                            </div>
                        </td>
                       
                         <td class="py-3  text-center "> 
                                <span class="font-light  rounded-md text-xs p-2 bg-blue-200">NA</span>
                        </td>
                           
                      
                    
                         <td class="py-3 px-6 text-left ">
                            <div class="flex items-center">
                              
                                <span class="font-light"><?php echo e($disp->observaciones_disp); ?></span>
                            </div>
                        </td>
                          <td class="py-3 px-6 text-left whitespace-nowrap d-flex justify-content-center">
                               NA
                            </td>
                          
                          
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
  </div>
 <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
           
            </div>
            <div class="modal-body">
              <form method="POST"  action="<?php echo e(route('Incidencias2post')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="idt" name="idt">
         
                <div class="col-sm-12 col-md-12 col-lg-12 mb-3">
                    <label for="exampleInputEmail1" class="form-label">Estado del equipo:</label>
                    <select class="form-select js-example-basic-multiple" name="status" id="status"  required>
                     
                      <option value="BUENO">BUENO</option>
                       <option value="REGULAR">REGULAR</option>
                        <option value="MALO">MALO</option>
                    </select>
                </div>
             <div class="col-sm-12 col-md-12 col-lg-12 mb-3">
                    <label for="exampleInputEmail1" class="form-label">Observaciones:</label>
                   <div class="form-floating">
  <textarea class="form-control" id="obs" name="obs"></textarea>
</div>
                </div>
                <div class="mt-4 d-flex justify-content-center">
                  <button type="submit" class="btn btn-dark">GUARDAR</button>                 
                </div>
              </form>
            </div>
        </div>
    </div>
</div>
<!-- Modal  asignacion completada-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="icon" href="http://mipueblitofoods.net/public/images/icono.png"> 

<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lexend+Tera:wght@300&family=Poiret+One&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" >

<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet" >
<link href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css" rel="stylesheet" >

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.4.0/js/dataTables.fixedHeader.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

 <script>
        $("body").on("click", "#mydatatable a", function(event) {
            event.preventDefault();
            idsele = $(this).attr("href");
            id= $(this).parent().parent().children("td:eq(0)").text();
        
            //Cargamos en el formulario los valores del registro
        
            $("#idt").val(id);
         
            eliminaEspacio();
        });
        function eliminaEspacio(){
    
    $('input').val(function(_, value) {
    return $.trim(value);
    });
    
    }
        </script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#mydatatable tfoot th').each(function () {
            var title = $(this).text();
            $(this).html('<input type="text" class="form-control" placeholder="Filtrar.."  style="font-size: 12px;"/>');
        });

        var table = $('#mydatatable').DataTable({
            "dom": '<"float-left"B><"float-right"f>t<"float-left"i><"float-right"p><"clearfix">',
            "responsive": false,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
            },
            "order": [
                [0, "desc"]
            ],
            "initComplete": function () {
                this.api().columns().every(function () {
                    var that = this;

                    $('input', this.footer()).on('keyup change', function () {
                        if (that.search() !== this.value) {
                            that
                                .search(this.value)
                                .draw();
                        }
                    });
                })
            },
            "buttons": [
                {
                extend:    'copyHtml5',
                text:      '<i class="fa fa-copy"></i>',
                titleAttr: 'Copiar al portapapeles'
            },
            {
                extend:    'excel',
                text:      '<i class="fa fa-file-excel"></i>',
                titleAttr: 'Descargar informaci贸n en excel'
            },
            {
                extend:    'pageLength',
                text:      '<i class="fa fa-ellipsis"></i>',
                titleAttr: 'Mostrar resultados'
            }
  ],
        });
    });
</script>
      
      <script>
        Highcharts.chart('container', {
       chart: {
           type: 'column',
           backgroundColor:'#ADAFA9 ',
       },
       title: {
           text: 'EQUIPOS'
       },
       subtitle: {
           text: 'Total de equipos de computo.'
       },
       xAxis: {
           type: 'category',
           labels: {
               rotation: -45,
               style: {
                   fontSize: '13px',
                   fontFamily: 'Verdana, sans-serif'
               }
           }
       },
       yAxis: {
           min: 0,
           title: {
               text: 'EQUIPOS'
           }
       },
       legend: {
           enabled: false
       },
       series: [{
           name: 'En uso',
           data: <?= $datos ?>,
           color: '#81ED11',
           dataLabels: {
               enabled: true,
               rotation: -90,
               color: '#FFFFFF',    
               align: 'right',
               y: 10,
               style: {
                   fontSize: '13px',
                   fontFamily: 'Verdana, sans-serif',  
               }
           }
       }
   ]
   });
        </script>
        <script>
          Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
     
           backgroundColor:'#ADAFA9 ',
    },
    title: {
        text: 'MEMORIA RAM'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: ''
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
            enabled: true,
            format: '<b>{point.name}</b>:<br>{point.percentage:.1f} %<br>Equipos: {point.y}',
            }
        }
    },
    series: [{
        name: 'Porcentaje',
        colorByPoint: true,
        data:<?= $datos2 ?>,
    }]
});
            </script>
             <script>
          Highcharts.chart('container3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
     
           backgroundColor:'#ADAFA9 ',
    },
    title: {
        text: 'ESTADO DE LOS EQUIPOS'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
        point: {
            valueSuffix: ''
        }
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
            enabled: true,
            format: '<b>{point.name}</b>:<br>{point.percentage:.1f} %<br>Equipos: {point.y}',
            }
        }
    },
    series: [{
        name: 'Porcentaje',
        colorByPoint: true,
        data:<?= $datos3 ?>,
    }]
});
            </script>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/agroinbi/public_html/MiPueblito/resources/views/ti/EstadisticasEquipos.blade.php ENDPATH**/ ?>