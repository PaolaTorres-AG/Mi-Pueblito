
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>COA</title>

<style type="text/css">
    * {
        font-family: Verdana, Arial, sans-serif;
    }
    table{
       
        
        border-collapse: collapse;
    }
   
    
    p.small{
        font-size: 8px;
        padding: 0;
    }
   
 #sgc{
    width: 100%;
    border-collapse: collapse;
    padding:0;
 }
 #sgc td, th {
  border: 1px solid black;
  padding:0;
}
#sgc th {
  height: 40px;
}
img.resize {
   width: 30%;
   height: 30%;
   max-height: 125px;
}
img.firmas {
   width: 35%;
   height: 10%;
   max-height: 125px;
}
p.titles{
    text-align: center ;
    font-size: 12px;
    font-weight: bold;

}
p.titlesleft{
    text-align: right ;
    font-size: 12px;
    font-weight: bold;
    margin: 0;
  padding:0;
}
p.titlesright{
    text-align: left ;
    font-size: 12px;
    font-weight: bold;
}
p.textn{
    text-align: left ;
    font-size: 12px;
    margin: 0;
  padding:0;
}
.textsmal{
    text-align: left ;
    font-size: 12px;
}

    .texttitle{
        text-align: center ;
    font-size: 12px;
    font-weight: bold;
}
 table{
    padding:0
 }

 @page {
                margin: 120px 50px;
            }

            header {
                position: fixed;
                top: -60px;
                left: 0px;
                right: 0px;
                height: 50px;

                /** Extra personal styles **/
            
                text-align: center;
                line-height: 8px;
            }

            footer {
                position: fixed; 
                bottom: -60px; 
                left: 0px; 
                right: 0px;
                height: 50px; 
                text-align: center;
                line-height: 10px;
            }

@media print {
* {
    -webkit-print-color-adjust: exact !important; /*Chrome, Safari */
    color-adjust: exact !important;  /*Firefox*/
  }
}

</style>

</head>
<body>
    
    <header>
        <?php $__currentLoopData = $sgc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sgc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <table style="height: 66px; width: 100%; border-collapse: collapse;" border="1" cellspacing="0" cellpadding="0">
        <tbody>
        <tr style="height: 15px;">
        <td style="width: 22.5369%; height: 40px;" rowspan="6"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://www.agroin.com.mx/img/logo-final.png" alt="" width="119" height="62" /></td>
        <td style="width: 44.3067%; text-align: center; font-size: 8px; height: 15px;" rowspan="2"><strong>CERTIFICADO DE AN&Aacute;LISIS</strong></td>
        <td style="width: 30.1563%; height: 5px;">
        <div><strong style="font-size: 8px;">&nbsp;C&Oacute;DIGO&nbsp;</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->codigo); ?></span></div>
        </td>
        </tr>

        <tr style="height: 18px;">
        <td style="width: 30.1563%; height: 10px;">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;FECHA DE ELABORACI&Oacute;N </strong><span style="font-size: 8px; text-align: center;"><?php echo e($sgc->fecha_elaboracion); ?></span></div>
        </div>
        </td>
        </tr>

        <tr style="height: 18px;">
        <td style="width: 44.3067%; height: 10px;">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;RESPONSABLE</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->responzable); ?></span></div>
        </div>
        </td>
        <td style="width: 30.1563%; height: 10px;">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;No. DE REVISI&Oacute;N</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->num_revision); ?></span></div>
        </div>
        </td>
        </tr>

        <tr style="height: 15px;">
        <td style="width: 44.3067%; height: 10px;">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;RETENER POR</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->retener); ?></span></div>
        </div>
        </td>
        <td style="width: 30.1563%; height: 10px;">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;FECHA DE PUBLICACI&Oacute;N</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->fecha_publicacion); ?></span></div>
        </div>
        </td>
        </tr>

        <tr style="height: 18px;">
        <td style="width: 74.463%; height: 10px;" colspan="2">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;COMPA&Ntilde;&Iacute;A</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->empresa); ?></span></div>
        </div>
        </td>
        </tr>

        <tr style="height: 18px;">
        <td style="width: 74.463%; height: 10px;" colspan="2">
        <div>
        <div><strong style="font-size: 8px;">&nbsp;DOMICILIO&nbsp;</strong> <span style="font-size: 8px; text-align: center;"><?php echo e($sgc->domicilio); ?></span></div>
        </div>
        </td>
        </tr>

        </tbody>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </header>
    <p></p>


<?php $__currentLoopData = $solicitud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    

  <table width="100% " style="padding-0;margin:0">
          <tr>
        <td align="right">
    
      <p class="titlesleft">Fecha de aprobación: <?php echo e(Carbon\Carbon::parse($solicitud->updated_at)->locale('es')->isoFormat('DD MMM Y')); ?>   </p>

          
        </td>
    </tr>
    <tr>
        <td align="right">
            <p class="titlesleft" style="color:#FF0000">Folio: <?php echo e($solicitud->id); ?></p>
        </td>
    </tr>
  </table>

  <table width="100%">
    <tr>
     <td align="center">
            <p class="titles" >IDENTIFICACIÓN DE LA MUESTRA</p>
        </td>
    </tr>
    <td align="left">
        <p class="textn">Fecha de recepción: <label id="fr"> <?php echo e(Carbon\Carbon::parse($solicitud->fecha_recepcion)->locale('es')->isoFormat('DD MMM Y')); ?> </p></label>
        <p class="textn">Fecha de análisis: <?php echo e(Carbon\Carbon::parse($solicitud->created_at)->locale('es')->isoFormat('DD MMM Y')); ?></p>
        <p class="textn">Producto: <?php echo e($solicitud->producto); ?></p>
        <p class="textn">Código: <?php echo e($solicitud->codigo); ?></p>
        <p class="textn">Lote: <?php echo e($solicitud->lote); ?></p>
        <p class="textn">Muestreado por: <?php echo e($solicitud->usuario); ?></p>
        <p class="textn">Fecha de producción: <?php echo e(Carbon\Carbon::parse($solicitud->fecha_produccion)->locale('es')->isoFormat('DD MMM Y')); ?></p>
        
        <?php if($solicitud->estatus=="EN HOLD"): ?>
        <p class="textn">Estatus: <strong style="text-decoration-line: underline;"> RECHAZADO </strong></p>
<?php elseif($solicitud->estatus=="LIBERADO"): ?>
<p class="textn">Estatus: <strong style="text-decoration-line: underline;"> LIBERADO  </strong></p>
        <?php endif; ?>
    </td>   
</tr>
  </table>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <table width="100%">
    <tr>
     <td align="center">
            <p class="titles">RESULTADOS</p>
        </td>
    </tr>
    <td align="left">
        <p class="textn">A continuación, se describen los resultados de los parámetros evaluados en el laboratorio de control interno de Agroindustria de Aguascalientes. Únicamente avala la muestra tomada, transportada y entregada por el personal de muestreo o cliente al laboratorio. </p>
       
    </td>   
</tr>
  </table>
  <p>
  <p class="textn">Los límites máximos aplican de acuerdo con:<span class="textn" style="font-weight:bold"> ESPECIFICACIÓN INTERNA DE AGROIN  </span> </p>
<p class="titlesright"> MICROBIOLÓGICOS  </p>
  

  <table width="100%">
    <thead style="background-color: lightgray;">
      <tr style="background-color: #6AD22A;" class="texttitle">
       
        <th class="titles">PARÁMETRO </th>
        
        <th class="titles">RESULTADO </th>
        <th class="titles">LÍMITE MAX. </th>
        <th class="titles">UNIDADES </th>
        <th class="titles">MÉTODO </th>
        <th class="titles">REALIZÓ </th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $metodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metodos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
      
      <tr class="textsmal">
        
        <td align="left" ><?php echo e($metodos->analisis); ?></td>
        
        <?php if($metodos->limit=="AUSENCIA"): ?>
        <td align="center"><?php echo e($metodos->resultado); ?></td>
        <td align="center" style="background-color: #C6E2B5;"><?php echo e($metodos->limit); ?></td>
        <?php else: ?>
        <td align="center"> <?php echo e($metodos->resultado); ?></td> 
        <td align="center" style="background-color: #C6E2B5;">  <?php echo e($metodos->limit); ?></td>
        <?php endif; ?>
     
        <td align="center"><?php echo e($metodos->unidades); ?></td>
        <td align="center"><?php echo e($metodos->metodo); ?> </td>
        <td align="center"><?php echo e($metodos->realizado); ?>  </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<p class="small">UFC = Unidades Formadoras de Colonias; Los valores reportados “<” “menor que” indica que son menores al Límite de Detección del método referenciado; g = gramo; NMP = Numero Más Probable; * = Valor estimado. L. monocytogenes = Listeria monocytogenes. Listeria spp = Listeria especies. S. aureus = Staphylococcus aureus. E. Coli = Escherichia coli.</p>

<table width="100%" id="firmas">
    <tr>
     <td align="center">
            <p class="titles">APROBÓ RESULTADOS:</p>
        </td>
        <td align="center">
            <p class="titles">AUTORIZADO POR:</p>
        </td>
    </tr>
    <tr>
        <td align="center" style="margin:0;padding:0;width:100px">
            <img src="<?php echo e(public_path('images/MMacias.png')); ?>" alt="firma" class="firmas" align='middle' >
           </td>
           <td align="center" style="margin:0;padding:0;width:100px">
            <img src="<?php echo e(public_path('images/MFigueroa.png')); ?>" alt="firma" class="firmas" align='middle' >
           </td>
       </tr>  
       <tr>
        <td align="center">
               <p class="titles">JEFE DE LABORATORIO</p>
           </td>
           <td align="center">
               <p class="titles">GERENCIA DE LABORATORIO</p>
           </td>
       </tr> 

  </table>
  <br>

<footer>
    <?php $__currentLoopData = $sgcf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sgcf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p align="center" class="small"><?php echo e($sgcf->aviso1); ?></p>
    <p align="center" class="small"><?php echo e($sgcf->aviso2); ?></p> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
</footer>
  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Agroin\resources\views/ti/PDF.blade.php ENDPATH**/ ?>