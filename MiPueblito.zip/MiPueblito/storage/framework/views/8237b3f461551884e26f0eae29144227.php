
<?php $__env->startSection('title', 'LABORATORIO'); ?>
<?php $__env->startSection('content_header'); ?>
<?php $__currentLoopData = $solicitud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<p style="font-family: 'Lexend Tera', sans-serif;font-family: 'Poiret One', cursive;font-weight: bold;color:#48B406; text-align: right;">! HOLA <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?> ! </p>
 <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
 <div class=" m-0 p-0 card bg-gradient-to-tr  from-gray-500 to-gray-900   rounded-lg  text-white font-bold text-md">
  
  <div class="card-body m-2 p-0">
<h5 class="text-center">Solicitud de Análisis</h5> 
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('alert-' . $msg)): ?>
   
    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> <!-- end .flash-message -->

<div class="card p-2 m-0">
  <form class="  rounded" method="POST" >
    <?php echo csrf_field(); ?>
  
    <div class="container col-12">
      <div class="row col-12">
        <div class="col-sm-6 col-md-1 col-lg-1 mb-4">
            <label for="exampleInputEmail1" class="form-label text-sm">Folio</label>
            <input type="text" class="form-control text-sm"  id="folio" name="folio" required readonly value="<?php echo e($solicitud->id); ?>" >
        </div>
        <div class="col-sm-12 col-md-2 col-lg-2 mb-4">
          <label for="exampleInputEmail1" class="form-label text-sm">Idioma del COA</label>
          <input type="text" class="form-control text-sm"   required id="coa" name="coa" required readonly value="<?php echo e($solicitud->idioma); ?>">
      </div>
        <div class="col-sm-6 col-md-3 col-lg-3 mb-4">
            <label for="exampleInputEmail1" class="form-label text-sm">Estatus</label>
            <input type="text" class="form-control text-sm"  id="estatus" name="estatus" required readonly value="<?php echo e($solicitud->estatus); ?>" >
        </div>
 <div class="col-sm-6 col-md-2 col-lg-2 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Código</label>
    <input type="text" class="form-control text-sm"  id="codigoc" name="codigoc" required readonly value="<?php echo e($solicitud->codigo); ?>">
</div>
<div class="col-sm-6 col-md-2 col-lg-2 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Lote</label>
    <input type="text" class="form-control text-sm"  id="lote" name="lote"  required  readonly value="<?php echo e($solicitud->lote); ?>">
</div>
<div class="col-sm-6 col-md-2 col-lg-2 mb-4">
  <label for="exampleInputEmail1" class="form-label text-sm">Fecha de elaboración</label>
  <input type="text" class="form-control text-sm"  id="felab" name="felab"  required  readonly value="<?php echo e($solicitud->fecha_produccion); ?>">
</div>
<div class="col-sm-6 col-md-2 col-lg-2 mb-4">
  <label for="exampleInputEmail1" class="form-label text-sm">Fecha de caducidad</label>
  <input type="text" class="form-control text-sm"  id="fcad" name="fcad"  required  readonly value="<?php echo e($solicitud->fecha_caducidad); ?>">
</div>
<div class="col-sm-6 col-md-3 col-lg-3 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Solicitado por</label>
    <input type="text" class="form-control text-sm"  id="" name=""  required  readonly value="<?php echo e($solicitud->usuario); ?>">
</div>
<div class="col-sm-6 col-md-2 col-lg-2 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Fecha de solicitud</label>
    <input type="text" class="form-control text-sm"  id="" name=""  required  readonly value="<?php echo e($solicitud->created_at); ?>">
</div>
<div class="col-sm-6 col-md-3 col-lg-3 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Muestra recibida por</label>
    <input type="text" class="form-control text-sm"  id="" name=""  required  readonly value="<?php echo e($solicitud->recibio); ?>">
</div>
<div class="col-sm-6 col-md-2 col-lg-2 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Fecha de recepción </label>
    <input type="text" class="form-control text-sm"  id="lote" name="lote"  required  readonly value="<?php echo e($solicitud->fecha_recepcion); ?>">
</div>
 <div class="col-sm-12 col-md-6 col-lg-6 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Producto</label>
    <input type="text" class="form-control text-sm"  id="producto" name="producto"  required readonly value="<?php echo e($solicitud->producto); ?>">
</div>
<div class="col-sm-12 col-md-6 col-lg-6 mb-4">
    <label for="exampleInputEmail1" class="form-label text-sm">Comentarios</label>
    <textarea class="form-control text-sm" name="indicaciones" id="indicaciones" readonly ><?php echo e($solicitud->comentarios); ?> </textarea>
</div>

<?php if($pdf == 0 && $solicitud->estatus== "LIBERADO" || $solicitud->estatus== "EN HOLD"): ?>
<div class="col-sm-1 col-md-1 col-lg-1 mb-4">
  <label for="exampleInputEmail1" class="form-label">COA-ESP</label>
 <p> <a href="<?php echo e(URL::route('generate.invoice.pdf', ['id' => Crypt::encrypt($solicitud->id) ])); ?>" class="btn btn-secondary"><i class="fa-solid fa-file-pdf"></i></a></p>
</div>
<div class="col-sm-1 col-md-1 col-lg-1 mb-4">
  <label for="exampleInputEmail1" class="form-label">COA-ING</label>
 <p> <a href="<?php echo e(URL::route('generatePdfIng', ['id' => Crypt::encrypt($solicitud->id) ])); ?>" class="btn btn-secondary"><i class="fa-solid fa-file-pdf"></i></a></p>
</div>

<?php endif; ?>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </form>
</div>

<?php if($solicitud->estatus != "CANCELADO"): ?>
<div class=" m-0 p-0 card bg-gradient-to-tr  from-gray-500 to-gray-900  rounded-lg  text-white font-bold text-md">
    <div class="card-body m-2 p-0">
        <h5 class="text-center">Análisis</h5>
    </div>
  </div>


<div class="table-responsive p-3 mt-3 bg-gray-300 rounded-lg ">
<table class="table  data-table table-hover rounded-lg text-xs " id="example">
  <thead>
      <tr style="border-style:none !important"> 
          <th>PARAMETRO</th>
          <th>RESULTADO</th>
          <th>LIMITE MAX</th>
          <th>UNIDADES</th>
          <th>METODO</th>
          <th>REALIZO</th>
      </tr>
  </thead>
  <tbody style=" border-radius: 25px !important;">
      <?php $__currentLoopData = $metodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablametodos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr > 
              <td><?php echo e($tablametodos->analisis); ?></td>
              <td><?php echo e($tablametodos->resultado); ?></td>
              <td><?php echo e($tablametodos->limit); ?></td>
              <td><?php echo e($tablametodos->unidades); ?></td>
              <td><?php echo e($tablametodos->metodo); ?></td>
              <td><?php echo e($tablametodos->realizado); ?></td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOwAAAB9CAMAAACWN3/AAAAAwFBMVEX///8AAACuyQxAQEB/f3+/v7/v7+8QEBAwMDDPz8/f399wcHAgICDC10mfn5/6/PCPj4/W5IWvr6/r8cJQUFBgYGDM3We40Cr1+OHS4Xfh66Tw9dG90zrm7rPH2ljb55T7x1380GT82GqkvQv81Iz+89/+33D+79VXZAMmLgH/+/T70IH9579sfgT6xVqYsQr+6nn94Kv97MpiZVA/SgKDlwi8yHT7zXdKVwL7yGx3iwQPEgD815b95XYzPQFVV1DSYYu2AAAJEElEQVR4nO1caWObOBA1Acxl4zuxncvpkbRNmzZ7d7fd/f//akEgaUYHRtgcIX6fklgBPTTHm5HwYHDCCSeccMJLRtj2BBrE0Ju3PYXmEFmjYdtzaAquZVlR25NoCqOErOW2PYtm4KRcX4khB1aGV2HIdk7WCtqeSf2YUq6W3/ZUakfoMbKW0/Zk6sbSAui5Ic8hV8tuezq1Yughsta07QnViRXmank9rghcS0R/DXk4kshacduTqguOzNXyeqoaAwVXy1q2Pa164CvJWr2s46dqrr00ZKgTLR/+Ylr+rBfXs9lmnOJmtl2sa5nuYbDhagZISZWv4y9vz8dnIi5mXeOL2DmYe7k6fjGTeVKcd4ou0omjgWDVew15fXujJZph0wCJskA6kZgtileF5c/l5mIP0xRXzRApAaQT83WEhqyv49ezMkyJKU8aIrMHSCfSVIM0hrqOn2yvSjJNMWuQUQEiyIuJCKQeFYa8ODdgmuCiSUpaoDUE8hCut1j+TLay+SaJ9ZxkWI1lXzbKSgOoE2EFizwZ1fHrmUBzs10gl1yownMX7NjRcorUT2GN7Hc8U6+Y7NAdSD8oo2JrHao+WsA1O78uurRg6uO6KJQH1on4M6SrSB2/GJdlmmKCjLl9M44LMwzsrCY5CVAdb0td/rZLZCWdiIFs/Ffuq5vSYheEstujzrwCUFNcUd4A1fiBTvri1kQM8TDVdupR6UQM6tK/vaVUy9kvw5qRPcaEDwDSiepKLiSfffy9ItUBN+Rzw//79Pz4+Pjus/H9dFDrRIw0DX/J5/v2jwo3uaxmxQ+7p12Cpz/fV7inAjqdiOH/RS34S7X9+EpZ9v3T7o5gt/tU4Z4ykE7U0VhQZfD1o86v9yDLV3uTMsb3hOubFHe7dxXuKUGvEzkmG2rBH7QRex+I0xrWPJ+fEq739z/v39zdPR2hEg4hV82mDlvWv//JB1bYj59VWNgfu4Trz2/fUra7IwQppBOV23VsWb/+y0ea78fPzD128JiS/ZbgZ0L22fiWIlCTScngki7r5j841ng/PiVr2l58R8neH4Ms0olK22RC77rE4CJsKijFZ2jGv5j+t4h9OnFCNf9VuiioXDDdjx+f3RhPb/KUsk2QcN0Z/7cAVLwp8smCSf7sd+jgpvvxZ2cVwulznnruDl/YfTqRmTBVhwUl/j5MqlUAP3a7TFMc7LHFOpHX3HyaZZKyGltzOU3wTNTi94MdFhU7kk68pFXZFTS/UnJLhUXlaT48PBxBGBdOnLnrGLlaOSHdPSCTFI+IbClXsSQrUyIRBNOVbdtLR6Mswyj5EN41cJbJeDuKy9lL6DoJ3JLGVagTZzqu6k0SGTE3mxHRKhbVLNkPEX7GQwdcdgXjvA0nmDwgO8CXX5VSN0Vp5FzLVfD0lfraAT6Z4QcC2aGPn7ErHEcCUg6RTX9JLGWOhpcowYp0YhFX1camCCo+fNvOWHkxJku0jD2iWhyMz3+ymckoyFJPonlQ88Q5CqQfTznqFgpuRSoMOZu7nTnfMCbTjSFZj6wue3EoHz8n44OIXN6n15XJkoe9IuEinHpl1lZ/yHbCGoE6ebdHd5GP4TtBcw/aT/YzCE2uMD604XJJZFNbsZnbDZda+yoxX871SivvUFko3ogsvI8WPPRFso44Hj1vsnZzDVnBbon7F+bAAktkNnyhl7JhUfkTKYw7+wdOFkbxNAN6Qkhd8TEKsthHiWEUZSCULNHS8HZ/kZQtiG7kOUpmFWOykTBezNckv8UasuKT9IvtWK8TOddiKYtSC1qWqfToCUaIrIvHyyWFy0xGJivqn0h64NKdKZAuYLppXy8bqUZkyEuRPefEyQrjFeuSTpFEIYmsJw51CslqdeI146oPTqprwPLHU+2MZU+HkR3h8dL0B9lyEeOWyErByFX9Ed6XAVoQ34/ZX3ti1QgEmO7OkKyN/64qjOd0vERWWkRXcwn2H6pp8qRT5igA8nt+r1BnUxqyrma8exyyKJJCA9wwrgVZhyNSXqd+spKDF5DV5kjusOVa2ShX8zBnabSqhmyoGX8csjqdOOFcS7aykQpjfuqpu6woQMGl1Mw0puZyCFnxkC0DN+Kzsh0U9NyoLkjno9AzUx1ZXz1+RWkdQFarExfGCyt4BDXkqaV0wpGObOr68ps0Q5aRDiCr1YljQ48lQLEu97yhpWpgYLkIyQaWqk502AWrk9V2GcDCmuwqqsqf9HmKXht4WrLKdEKkQAhvYU5W3z8CC2tyTgnpk3x9iKcs0VplXDVkyQJgQyZlW74WlckijQcrDaCdzBr36IoRmL0Ptb6XNyeUZDPXggmfdLDoWlQlq9WJ8EyW4d44Kn/yeeRtlilJbG7WN0RtGUdxDZuSGDrpg2EVblWyukO2gwE4Sml4dAdFAeqqcximyd1csZUKkfca/Sh2XSfPZ8yuK5LV6kR2bCeF6R4qiu+UxRC/grsMgYyUyeaNJPhwuNqpRraglwLPUZruyeA3UNkkwxW9nUfa2C57wAqyUicYhLdqZB0bAJfXQD0J8Yl8cjUuOnxKtiEo4EyCOPlDnP9lzqYpjGJ0Vzlfe4oiuXpHACJIN0308xMBX7JSf3LwudnU2vfuXgduA99lc0yy6cNXt1lUDYwWAMniAy3mnpzmGFn+pcGxI19TA19tQLRYjWtwHIJ07AW2QP61DlC34zKARi4TpUGI+YjZFKaltgEKd7zBQ7tSRkqDCCgvYnTjkZzs2gS0Y2CxTDKbHf7IdyBHdpJlVnnq8EtukTcAuLSAGBMbhsfwxL3lzgSnDEAwgtYijdLmLwvGqEBYdSQ2UVzyWoDtBjArrvJGWRhHmVhz5t2xYIoJ14w0RjFP7tS76scBf715TNgxR+7Ou9tHxfp6Mx5TacEq+tbfsWoAzIs78pp6nWB7ta2/KdgA2ML2MDyJ0B/o6x94c/UVLOzNK/JYvh3yCkLxxStaWBaduvF9IbWCR6eKbzG8JLDo1IHvlKgbfIOg7Zfx6wcv5DvwzSg1A5z96n/a4c03wzd7XyB4w6L/opgfwt17MPXFg3PtfyQGHdXeywnAtfcOCw4I9bShCDBZMPQ+OJ1wwgmdwP/W92x8A1sCMwAAAABJRU5ErkJggg=="> 
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lexend+Tera:wght@300&family=Poiret+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://demos.creative-tim.com/notus-js/assets/styles/tailwind.css">
<link rel="stylesheet" href="https://cdn.datatables.net/v/bs4-4.1.1/dt-1.10.18/datatables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/css/jquery-editable.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/v/bs4-4.1.1/dt-1.10.18/datatables.min.js"></script>
    <!-- Buttons -->
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.53/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.53/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script>$.fn.poshytip={defaults:null}</script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/js/jquery-editable-poshytip.min.js"></script>
   
  
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Agroin\resources\views/ti/MiSolicitud.blade.php ENDPATH**/ ?>